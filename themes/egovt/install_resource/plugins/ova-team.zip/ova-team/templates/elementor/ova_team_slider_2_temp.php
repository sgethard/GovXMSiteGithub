<?php
$category = $args['category'];

$data_options['items']              = $args['item_number'];
$data_options['slideBy']            = $args['slides_to_scroll'];
$data_options['margin']             = $args['margin_items'];
$data_options['autoplayHoverPause'] = $args['pause_on_hover'] === 'yes' ? true : false;
$data_options['loop']               = $args['infinite'] === 'yes' ? true : false;
$data_options['autoplay']           = $args['autoplay'] === 'yes' ? true : false;
$data_options['autoplayTimeout']    = $args['autoplay_speed'];
$data_options['smartSpeed']         = $args['smartspeed'];
$data_options['dots']               = $args['dot_control'] === 'yes' ? true : false;

$show_name = $args['show_name'];
$show_social = $args['show_social'];
$show_job = $args['show_job'];
$show_email = $args['show_email'];
$show_phone = $args['show_phone'];

if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count']
	);
} else {
	$args_new= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_team',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_team_order = [];
if( $args['orderby_post'] === 'ova_team_met_order_team' ) {
	$args_team_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_team_order = [
		'orderby'        => $args['orderby_post'],
	];
}

$args_team = array_merge( $args_new, $args_team_order );

$teams  = new \WP_Query($args_team);

?>
<div class="archive_team elementor-team ova-team-slider-2 ">
	<div class="content slide-team owl-carousel owl-theme" data-options="<?php echo esc_attr(json_encode($data_options)) ?>">
		<?php if($teams->have_posts() ) : while ( $teams->have_posts() ) : $teams->the_post(); ?>

			<div class="items elementor-items">
				<?php 

				$id = get_the_id();

				$avatar = get_post_meta( $id, 'ova_team_met_avatar', true );

				$job = get_post_meta( $id, 'ova_team_met_job', true );
				$email = get_post_meta( $id, 'ova_team_met_email', true );
				$phone = get_post_meta( $id, 'ova_team_met_phone', true );
				$list_social = get_post_meta( $id, 'ova_team_met_group_icon', true );

				?>

				<div class="content_info">
					<div class="ova-media">
						<?php if( ! empty( $avatar ) ){ ?>
							<a href="<?php echo get_the_permalink() ?>">
								<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive" alt="<?php echo get_the_title() ?>">
							</a>
						<?php } ?>
					</div>
					<div class="ova-info-content">

						<?php if( ! empty( $list_social ) && $show_social == 'yes' ) { ?>
						<div class="ova-social">
							<ul>
								<?php 
								foreach( $list_social as $social ){

									$class_icon = isset( $social['ova_team_met_class_icon_social'] ) ? $social['ova_team_met_class_icon_social'] : '';
									$link_social = isset( $social['ova_team_met_link_social'] ) ? $social['ova_team_met_link_social'] : '';
									?>
									<li>
										<a href="<?php echo esc_url( $link_social ); ?>" title="<?php echo esc_url( $link_social ); ?>">
											<i class="<?php echo esc_attr( $class_icon ) ?>"></i>
										</a>
									</li>
									<?php
								}
								?>
							</ul>
						</div>
						<?php } ?>
						<?php if( $show_name == 'yes' ) { ?>
						<a href="<?php echo get_the_permalink() ?>" class="name second_font" >
							<?php echo get_the_title() ?>
						</a>
						<?php } ?>

						<?php if( ! empty( $job ) && $show_job == 'yes' ) { ?>
							<p class="job">
								<?php echo esc_html( $job ) ?>
							</p>
						<?php } ?>

						<?php if( ! empty( $email ) && $show_email == 'yes' ) { ?>
							<div class="ova-email">
								<i class="fa fa-envelope-o"></i>
								<a href="mailto:<?php echo esc_attr( $email ) ?>" ><?php echo esc_html( $email ) ?></a>
							</div>
						<?php } ?>
						<?php if( ! empty( $phone ) && $show_phone == 'yes' ) { ?>
							<div class="ova-phone">
								<i class="fa fa-phone"></i>
								<a href="tel:<?php echo esc_attr( $phone ) ?>" ><?php echo esc_html( $phone ) ?></a>
							</div>
						<?php } ?>

						

					</div>
				</div>

			</div>

		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>

</div>
