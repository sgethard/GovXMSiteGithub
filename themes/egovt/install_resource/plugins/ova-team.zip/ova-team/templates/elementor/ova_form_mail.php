<?php
$email = $args['mail'];
$thank_page = $args['thank_page'];
$error_page = $args['error_page'];

if( ! empty( $email ) ){
?>
<form action="">
	<div class="ova-form-mail">
		<div class="con">
			<div class="input name">
				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<input type="text" class="required field" name="your_name" value=""  id="your-name" placeholder="<?php esc_html_e( 'Name', 'ova-team' ); ?>" aria-label="<?php esc_html_e( 'Name', 'ova-team' ); ?>" />
			</div>
			<div class="input email">
				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<input type="email" class="required field" name="your_email" value=""  id="your-email" placeholder="<?php esc_html_e( 'Email', 'ova-team' ); ?>" aria-label="<?php esc_html_e( 'Email', 'ova-team' ); ?>" />
			</div>

			<div class="input subject">
				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<input type="text" class="required field" name="your_subject" value="" id="your-subject" placeholder="<?php esc_html_e( 'Subject', 'ova-team' ); ?>" aria-label="<?php esc_html_e( 'Subject', 'ova-team' ); ?>" />
			</div>

		</div>

		<div class="con">
			<div class="input comment">
				<span class="error"><?php esc_html_e( 'field is required', 'ova-team' ) ?></span>
				<textarea name="your_comment" class="required field" cols="40" rows="10"  id="your-comment" placeholder="<?php esc_html_e( 'Write your message...', 'ova-team' ); ?>" aria-label="<?php esc_html_e( 'Write your message...', 'ova-team' ); ?>"></textarea>
			</div>
		</div>
		<div class="submit">
			<input type="submit" value="<?php esc_html_e( 'Send Message', 'ova-team' ) ?>" class="second_font" id="form-submit">
			<input type="hidden" name="email_to" value="<?php echo $email ?>">
			<input type="hidden" name="email_from_element" value="send_mail">
			<input type="hidden" name="thank_page" value="<?php echo $thank_page ?>">
			<input type="hidden" name="error_page" value="<?php echo $error_page ?>">
		</div>

	</div>
</form>
<?php
}
// end if empty email
