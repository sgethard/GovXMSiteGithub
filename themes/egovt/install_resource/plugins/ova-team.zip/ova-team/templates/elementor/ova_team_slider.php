<?php
$category = $args['category'];

$data_options['items']              = $args['item_number'];
$data_options['slideBy']            = $args['slides_to_scroll'];
$data_options['margin']             = $args['margin_items'];
$data_options['autoplayHoverPause'] = $args['pause_on_hover'] === 'yes' ? true : false;
$data_options['loop']               = $args['infinite'] === 'yes' ? true : false;
$data_options['autoplay']           = $args['autoplay'] === 'yes' ? true : false;
$data_options['autoplayTimeout']    = $args['autoplay_speed'];
$data_options['smartSpeed']         = $args['smartspeed'];
$data_options['dots']               = $args['dot_control'] === 'yes' ? true : false;

// echo '$data_options:<br>';
// echo '<pre>';
// var_dump($data_options);
// echo '</pre>';

$show_name = $args['show_name'];

if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count']
	);
} else {
	$args_new= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_team',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_team_order = [];
if( $args['orderby_post'] === 'ova_team_met_order_team' ) {
	$args_team_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_team_order = [
		'orderby'        => $args['orderby_post'],
	];
}

$args_team = array_merge( $args_new, $args_team_order );

$teams  = new \WP_Query($args_team);

?>

<div class="container">
	<div class="row">
		<div class="ova-team-slider">
			<div class="content slide-team owl-carousel owl-theme" data-options="<?php echo esc_attr(json_encode($data_options)) ?>">
				<?php if($teams->have_posts() ) : while ( $teams->have_posts() ) : $teams->the_post(); ?>

					<div class="items elementor-items">
						<?php 

						$id = get_the_id();

						$avatar = get_post_meta( $id, 'ova_team_met_avatar', true );
						$job = get_post_meta( $id, 'ova_team_met_job', true );

						?>

						<div class="content_info">
							<div class="ova-media">
								<?php if( ! empty( $avatar ) ){ ?>
									<a href="<?php echo get_the_permalink() ?>" style="background-image: url(<?php echo esc_url( $avatar ) ?>)" title="<?php esc_html_e('Media', 'ova-team'); ?>">
									</a>
								<?php } ?>
							</div>
							<div class="ova-info">

								<?php if( $show_name == 'yes' ) { ?>
								<a href="<?php echo get_the_permalink() ?>" class="name second_font" >
									<?php echo get_the_title() ?>
								</a>
								<?php } ?>

								<?php if( ! empty( $job ) && $show_job == 'yes' ) { ?>
									<p class="job">
										<?php echo esc_html( $job ) ?>
									</p>
								<?php } ?>

							</div>
						</div>
					</div>

				<?php endwhile; endif; wp_reset_postdata(); ?>
			</div>

		</div>
	</div>
</div>
