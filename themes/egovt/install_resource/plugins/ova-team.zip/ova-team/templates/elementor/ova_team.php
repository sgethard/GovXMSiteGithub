<?php
$category = $args['category'];
$number_column = $args['number_column'];

$show_social = $args['show_social'];
$show_name = $args['show_name'];
$show_job = $args['show_job'];
$show_email = $args['show_email'];
$show_phone = $args['show_phone'];
$target_blank = $args['blank_social'];
$target_html = "";
if ( $target_blank === 'yes' ) {
	$target_html = "target='_blank'";
}

if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count']
	);
} else {
	$args_new= array(
		'post_type' => 'team',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_team',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_team_order = [];
if( $args['orderby_post'] === 'ova_team_met_order_team' ) {
	$args_team_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => $args['order'],
	];
} else { 
	$args_team_order = [
		'orderby' => $args['orderby_post'],
		'order'   => $args['order'],
	];
}

$args_team = array_merge( $args_new, $args_team_order );

$teams  = new \WP_Query($args_team);

?>


		<div class="archive_team elementor-team <?php echo esc_attr( $number_column ) ?>">
			<div class="content">
				<?php if($teams->have_posts() ) : while ( $teams->have_posts() ) : $teams->the_post(); ?>

					<div class="items elementor-items">
						<?php 

						$id = get_the_id();

						$avatar = get_post_meta( $id, 'ova_team_met_avatar', true );

						$job = get_post_meta( $id, 'ova_team_met_job', true );
						$email = get_post_meta( $id, 'ova_team_met_email', true );
						$phone = get_post_meta( $id, 'ova_team_met_phone', true );
						$list_social = get_post_meta( $id, 'ova_team_met_group_icon', true );

						?>

						<div class="content_info">
							<div class="ova-media">
								<?php if( ! empty( $avatar ) ){ ?>
									<a href="<?php echo get_the_permalink() ?>">
										<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive" alt="<?php echo get_the_title() ?>">
									</a>
								<?php } ?>
							</div>
							<div class="ova-info-content">

								<?php if( ! empty( $list_social ) && $show_social == 'yes' ) { ?>
								<div class="ova-social">
									<ul>
										<?php
										$count_social = count( $list_social );
										$class_social = '';

										if ( $count_social && 1 == $count_social ) {
											$class_social = ' class="one-social"';
										}

										foreach( $list_social as $social ){

											$class_icon = isset( $social['ova_team_met_class_icon_social'] ) ? $social['ova_team_met_class_icon_social'] : '';
											$link_social = isset( $social['ova_team_met_link_social'] ) ? $social['ova_team_met_link_social'] : '';
											?>
											<li<?php printf( $class_social ); ?>>
												<a href="<?php echo esc_url( $link_social ); ?>" title="<?php echo esc_url( $link_social ); ?>" <?php echo $target_html; ?>>
													<i class="<?php echo esc_attr( $class_icon ) ?>"></i>
												</a>
											</li>
											<?php
										}
										?>
									</ul>
								</div>
								<?php } ?>
								<?php if( $show_name == 'yes' ) { ?>
								<a href="<?php echo get_the_permalink() ?>" class="name second_font" >
									<?php echo get_the_title() ?>
								</a>
								<?php } ?>

								<?php if( ! empty( $job ) && $show_job == 'yes' ) { ?>
									<p class="job">
										<?php echo esc_html( $job ) ?>
									</p>
								<?php } ?>

								<?php if( ! empty( $email ) && $show_email == 'yes' ) { ?>
									<div class="ova-email">
										<i class="fa fa-envelope-o"></i>
										<a href="mailto:<?php echo esc_attr( $email ) ?>" ><?php echo esc_html( $email ) ?></a>
									</div>
								<?php } ?>
								<?php if( ! empty( $phone ) && $show_phone == 'yes' ) { ?>
									<div class="ova-phone">
										<i class="fa fa-phone"></i>
										<a href="tel:<?php echo esc_attr( $phone ) ?>" ><?php echo esc_html( $phone ) ?></a>
									</div>
								<?php } ?>

								

							</div>
						</div>

					</div>

				<?php endwhile; endif; wp_reset_postdata(); ?>
			</div>

		</div>

