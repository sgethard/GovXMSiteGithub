<?php
global $post;

$id = get_the_ID();

$gallery = get_post_meta( $id, 'ova_por_met_gallery', true );
$date = get_post_meta( $id, 'ova_por_met_date', true );
$location = get_post_meta( $id, 'ova_por_met_location', true );
$department = get_post_meta( $id, 'ova_por_met_department', true );

?>

<div class="wrap-portfolio">
	<div class="single-por type1">
		<?php if( ! empty( $gallery ) ) { ?>
		<div class="por-gallery">
			<?php foreach( $gallery as $img_id => $val ) { 

				$img_alt = "";
				if ( !empty( $img_id ) ) {
					$img_alt = get_post_meta( $img_id, '_wp_attachment_image_alt', true );
					if ( empty( $img_alt ) ) {
						$img_alt = get_the_title( $img_id );
					}
				}

				?>
				<div class="item-gallery">
					<a href="<?php echo esc_url( $val ); ?>" data-fancybox="1">
						<img src="<?php echo esc_url( $val ); ?>" alt="<?php echo $img_alt; ?>">
					</a>
				</div>
			<?php } ?>
		</div>
		<?php } ?>
		<div class="wrap-content-por">
			<div class="content">
				<?php if( have_posts() ) : while( have_posts() ) : the_post();
					the_content();
				?>
				<?php endwhile; endif; wp_reset_postdata(); ?>
			</div>
			<div class="info-por">
				<div class="content-info">
					<div class="category">
						<label class="second_font"><?php esc_html_e( 'Category', 'ova-por' ) ?></label>
						<?php get_category_por_by_id_por( $id ) ?>
					</div>
					<div class="date">
						<label class="second_font"><?php esc_html_e( 'Date', 'ova-por' ) ?></label>
						<span><?php echo esc_html( $date ) ?></span>
					</div>

					<div class="location">
						<label class="second_font"><?php esc_html_e( 'Location', 'ova-por' ) ?></label>
						<span><?php echo esc_html( $location ) ?></span>
					</div>

					<div class="department">
						<label class="second_font"><?php esc_html_e( 'Department', 'ova-por' ) ?></label>
						<span><?php echo esc_html( $department ) ?></span>
					</div>

					<?php if( has_filter( 'ova_share_social' ) ){ ?>
				        <div class="share_social">
				        	<span class="ova_label second_font"><?php esc_html_e('Share ', 'ova-por'); ?></span>
				        	<?php echo apply_filters('ova_share_social', get_the_permalink(), get_the_title() ); ?>
				        </div>
			        <?php } ?>
				</div>
			</div>
		</div>
		<div class="single-foot-por">

	        <?php
			$prev_post = get_previous_post();
			$next_post = get_next_post();
			?>

			<?php if( $next_post || $prev_post ) { ?>

			<div class="ova-next-pre-post">
					<?php
					$prev_post = get_previous_post();
					$next_post = get_next_post();
					?>
					
					<?php
					if($prev_post) {
						?>
						<a class="pre" href="<?php echo esc_attr(get_permalink($prev_post->ID)); ?>" title="<?php esc_html_e('Previous', 'ova-por'); ?>">
							<span class="num-1">
								<span class="icon"><i class="arrow_carrot-left"></i></span>
							</span>
							<span  class="num-2">
								<span class="second_font text-label"><?php esc_html_e('Previous', 'ova-por'); ?></span>
								<span  class="second_font title" ><?php echo esc_html(get_the_title($prev_post->ID)); ?></span>
							</span>
						</a>
						<?php
					}
					?>

					<a class="ova-slash" href="<?php echo get_post_type_archive_link('ova_por'); ?>" title="<?php esc_html_e('Slash', 'ova-por'); ?>">
						<?php if( $prev_post && $next_post ){ ?>
							<span></span>
							<span></span>
							<span></span>
						<?php } ?>
					</a>
					
					<?php
					if($next_post) {
						?>
						<a class="next" href="<?php echo esc_attr(get_permalink($next_post->ID)); ?> " title="<?php esc_html_e('Next', 'ova-por'); ?>'">
							<span class="num-1">
								<span class="icon" ><i class="arrow_carrot-right"></i></span>
							</span>
							<span  class="num-2">
								<span class="second_font text-label"><?php esc_html_e('Next', 'ova-por'); ?></span>
								<span class="second_font title" ><?php echo esc_html(get_the_title($next_post->ID)); ?></span>
							</span>
						</a>
						<?php
					}
					?>
			</div>
			<?php } ?>

			
		</div>
	</div>
</div>

<?php
	get_portfolio_related_by_id( $id );
?>
