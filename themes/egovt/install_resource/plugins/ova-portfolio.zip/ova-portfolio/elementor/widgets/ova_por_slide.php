<?php
namespace ova_por_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_por_slide extends Widget_Base {


	public function get_name() {
		return 'ova_por_slide';
	}

	public function get_title() {
		return __( 'Portfolio Slide', 'ova-por' );
	}

	public function get_icon() {
		return 'fa fa-picture-o';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		wp_enqueue_style( 'owl-carousel', OVAPOR_PLUGIN_URI.'assets/libs/owl-carousel/assets/owl.carousel.min.css' );
		wp_enqueue_script( 'owl-carousel', OVAPOR_PLUGIN_URI.'assets/libs/owl-carousel/owl.carousel.min.js', array('jquery'), false, true );
		return [ 'script-elementor' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-por' ),
			]
		);

		$args = array(
			'taxonomy' => 'cat_por',
			'orderby' => 'name',
			'order'   => 'ASC'
		);

		$categories = get_categories($args);
		$catAll = array( 'all' => 'All categories');
		$cate_array = array();
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->slug] = $cate->cat_name;
			}
		} else {
			$cate_array[] = esc_html__( "No content Category found", "ova-por" );
		}

		$this->add_control(
			'category',
			[
				'label'   => __( 'Category', 'ova-por' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array_merge( $catAll, $cate_array )
			]
		);

		$this->add_control(
			'total_count',
			[
				'label'   => __( 'Total', 'ova-por' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 9
			]
		);

		$this->add_control(
			'orderby_post',
			[
				'label' => __( 'OrderBy Post', 'ova-por' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ID',
				'options' => [
					'ID'  => __( 'ID', 'ova-por' ),
					'ova_por_met_order_por' => __( 'Custom Order', 'ova-por' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => __( 'Additional Options', 'ova-por' ),
			]
		);


			$this->add_control(
				'margin_items',
				[
					'label'   => __( 'Space between 2 items', 'ova-por' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 30,
				]
				
			);

			$this->add_control(
				'item_number',
				[
					'label'       => __( 'Number of Items', 'ova-por' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Number of Items ', 'ova-por' ),
					'default'     => 3,
				]
			);

	

			$this->add_control(
				'slides_to_scroll',
				[
					'label'       => __( 'Slides to Scroll', 'ova-por' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-por' ),
					'default'     => 1,
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label'   => __( 'Pause on Hover', 'ova-por' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-por' ),
						'no'  => __( 'No', 'ova-por' ),
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'infinite',
				[
					'label'   => __( 'Infinite Loop', 'ova-por' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-por' ),
						'no'  => __( 'No', 'ova-por' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'   => __( 'Autoplay', 'ova-por' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-por' ),
						'no'  => __( 'No', 'ova-por' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label'     => __( 'Autoplay Speed', 'ova-por' ),
					'type'      => Controls_Manager::NUMBER,
					'default'   => 3000,
					'step'      => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => __( 'Smart Speed', 'ova-por' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
				]
			);

			$this->add_control(
				'dot_control',
				[
					'label'   => __( 'Show Dots', 'ova-por' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-por' ),
						'no'  => __( 'No', 'ova-por' ),
					],
					'frontend_available' => true,
				]
			);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_additional_options_new',
			[
				'label' => __( 'Style', 'ova-por' ),
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color Hover', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}}  .ova_por_slide.por_element .ovapor-item .content-item .title a:hover' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'cat_color',
				[
					'label' => __( 'Category Color Hover', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}}  .ova_por_slide.por_element .ovapor-item .content-item .category a:hover' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'button_color',
				[
					'label' => __( 'Button Color Hover', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}}  .ova_por_slide.por_element .ovapor-item .content-item .readmore a:hover' => 'background-color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'dot_color',
				[
					'label' => __( 'Dot Color Hover', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}}  .ova_por_slide.por_element .owl-dots .owl-dot.active span' => 'background-color: {{VALUE}}',
					],
				]
			);

		$this->end_controls_section();

	}


	protected function render() {

		$settings = $this->get_settings();

		$template = apply_filters( 'el_elementor_ova_sev', 'elementor/ova_por_slide_temp.php' );

		ob_start();
		ovapor_get_template( $template, $settings );
		echo ob_get_clean();
		
	}
}
