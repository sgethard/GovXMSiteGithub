<?php

if (!defined( 'ABSPATH' )) {
	exit;
}
if (!class_exists( 'Ova_Por_Customize' )){

	class Ova_Por_Customize {

		public function __construct() {
			add_action( 'customize_register', array( $this, 'ova_por_customize_register' ) );
		}

		public function ova_por_customize_register($wp_customize) {

			$this->ova_por_init( $wp_customize );

			do_action( 'ova_por_customize_register', $wp_customize );
		}


		public function ova_por_init( $wp_customize ){

			$wp_customize->add_section( 'ova_por_section' , array(
				'title'      => esc_html__( 'Portfolio', 'ova-por' ),
				'priority'   => 5,
			) );


			$wp_customize->add_setting( 'ova_por_total_record', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '9',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_por_total_record', array(
				'label' => esc_html__('Number of posts per page','ova-por'),
				'section' => 'ova_por_section',
				'settings' => 'ova_por_total_record',
				'type' =>'number'
			));


			$wp_customize->add_setting( 'ova_por_layout', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'three_column',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_por_layout', array(
				'label' => esc_html__('Layout','ova-por'),
				'section' => 'ova_por_section',
				'settings' => 'ova_por_layout',
				'type' =>'select',
				'choices' => array(
					'two_column'      => __( '2 column', 'ova-por' ),
					'three_column' => __( '3 column', 'ova-por' ),
					'four_column'      => __( '4 column', 'ova-por' ),
				)
			));

			$wp_customize->add_setting( 'ova_por_archive_type', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'classic',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_por_archive_type', array(
				'label' => esc_html__('Archive Type','ova-por'),
				'section' => 'ova_por_section',
				'settings' => 'ova_por_archive_type',
				'type' =>'select',
				'choices' => array(
					'classic'      => __( 'Classic', 'ova-por' ),
					'modern' => __( 'Modern', 'ova-por' ),
					'grid' => __( 'Grid', 'ova-por' ),
				)
			));

			$wp_customize->add_setting( 'ova_por_single_type', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'type1',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_por_single_type', array(
				'label' => esc_html__('Single Type','ova-por'),
				'section' => 'ova_por_section',
				'settings' => 'ova_por_single_type',
				'type' =>'select',
				'choices' => array(
					'type1'      => __( 'Type 1', 'ova-por' ),
					'type2' => __( 'Type 2', 'ova-por' ),
					'type3' => __( 'Type 3', 'ova-por' ),
				)
			));

			$wp_customize->add_setting( 'archive_background_por', array(
				'type' => 'theme_mod', // or 'option'
				'capability' => 'edit_theme_options',
				'theme_supports' => '', // Rarely needed.
				'transport' => 'refresh', // or postMessage
				'sanitize_callback' => 'sanitize_text_field' // Get function name 
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'archive_background_por', array(
				'label'             => esc_html__('Background Archive Portfolio', 'ova-por'),
				'section'           => 'ova_por_section',
				'settings'          => 'archive_background_por',    
			)));

			$wp_customize->add_setting( 'single_background_por', array(
				'type' => 'theme_mod', // or 'option'
				'capability' => 'edit_theme_options',
				'theme_supports' => '', // Rarely needed.
				'transport' => 'refresh', // or postMessage
				'sanitize_callback' => 'sanitize_text_field' // Get function name 
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'single_background_por', array(
				'label'             => esc_html__('Background Single Portfolio', 'ova-por'),
				'section'           => 'ova_por_section',
				'settings'          => 'single_background_por',    
			)));

			
			$wp_customize->add_setting( 'header_archive_por', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('header_archive_por', array(
				'label' => esc_html__('Header Archive','ova-por'),
				'section' => 'ova_por_section',
				'settings' => 'header_archive_por',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_header', '')
			));


			$wp_customize->add_setting( 'archive_footer_por', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('archive_footer_por', array(
				'label' => esc_html__('Footer Archive','ova-dep'),
				'section' => 'ova_por_section',
				'settings' => 'archive_footer_por',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_footer', '')
			));


			$wp_customize->add_setting( 'header_single_por', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('header_single_por', array(
				'label' => esc_html__('Header Single','ova-por'),
				'section' => 'ova_por_section',
				'settings' => 'header_single_por',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_header', '')
			));

			$wp_customize->add_setting( 'single_footer_por', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('single_footer_por', array(
				'label' => esc_html__('Footer Single','ova-dep'),
				'section' => 'ova_por_section',
				'settings' => 'single_footer_por',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_footer', '')
			));



		}

	}

}

new Ova_Por_Customize();






