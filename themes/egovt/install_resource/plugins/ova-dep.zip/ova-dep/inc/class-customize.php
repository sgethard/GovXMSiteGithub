<?php

if (!defined( 'ABSPATH' )) {
	exit;
}
if (!class_exists( 'Ova_Dep_Customize' )){

	class Ova_Dep_Customize {

		public function __construct() {
			add_action( 'customize_register', array( $this, 'ova_dep_customize_register' ) );
		}

		public function ova_dep_customize_register($wp_customize) {

			$this->ova_dep_init( $wp_customize );

			do_action( 'ova_dep_customize_register', $wp_customize );
		}


		/* Team */
		public function ova_dep_init( $wp_customize ){

			$wp_customize->add_section( 'ova_dep_section' , array(
				'title'      => esc_html__( 'Department', 'ova-dep' ),
				'priority'   => 5,
			) );


			$wp_customize->add_setting( 'ova_dep_total_record', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '14',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_dep_total_record', array(
				'label' => esc_html__('Number of posts per page','ova-dep'),
				'section' => 'ova_dep_section',
				'settings' => 'ova_dep_total_record',
				'type' =>'number'
			));


			$wp_customize->add_setting( 'ova_dep_layout', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'three_column',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_dep_layout', array(
				'label' => esc_html__('Layout','ova-dep'),
				'section' => 'ova_dep_section',
				'settings' => 'ova_dep_layout',
				'type' =>'select',
				'choices' => array(
					'two_column'      => __( '2 column', 'ova-dep' ),
					'three_column' => __( '3 column', 'ova-dep' ),
					'four_column'      => __( '4 column', 'ova-dep' ),
				)
			));


			$wp_customize->add_setting( 'archive_background_dep', array(
				'type' => 'theme_mod', // or 'option'
				'capability' => 'edit_theme_options',
				'theme_supports' => '', // Rarely needed.
				'transport' => 'refresh', // or postMessage
				'sanitize_callback' => 'sanitize_text_field' // Get function name 
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'archive_background_dep', array(
				'label'             => esc_html__('Background Archive Department', 'ova-dep'),
				'section'           => 'ova_dep_section',
				'settings'          => 'archive_background_dep',    
			)));

			$wp_customize->add_setting( 'single_background_dep', array(
				'type' => 'theme_mod', // or 'option'
				'capability' => 'edit_theme_options',
				'theme_supports' => '', // Rarely needed.
				'transport' => 'refresh', // or postMessage
				'sanitize_callback' => 'sanitize_text_field' // Get function name 
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'single_background_dep', array(
				'label'             => esc_html__('Background Single Department', 'ova-dep'),
				'section'           => 'ova_dep_section',
				'settings'          => 'single_background_dep',    
			)));
			

			$wp_customize->add_setting( 'header_archive_dep', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('header_archive_dep', array(
				'label' => esc_html__('Header Archive','ova-dep'),
				'section' => 'ova_dep_section',
				'settings' => 'header_archive_dep',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_header', '')
			));
			

			$wp_customize->add_setting( 'archive_footer_dep', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('archive_footer_dep', array(
				'label' => esc_html__('Footer Archive','ova-dep'),
				'section' => 'ova_dep_section',
				'settings' => 'archive_footer_dep',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_footer', '')
			));

			$wp_customize->add_setting( 'header_single_dep', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('header_single_dep', array(
				'label' => esc_html__('Header Single','ova-dep'),
				'section' => 'ova_dep_section',
				'settings' => 'header_single_dep',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_header', '')
			));

			$wp_customize->add_setting( 'single_footer_dep', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('single_footer_dep', array(
				'label' => esc_html__('Footer Single','ova-dep'),
				'section' => 'ova_dep_section',
				'settings' => 'single_footer_dep',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_footer', '')
			));

		}

	}

}

new Ova_Dep_Customize();






