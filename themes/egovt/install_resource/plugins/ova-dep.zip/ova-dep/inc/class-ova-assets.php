<?php 
defined( 'ABSPATH' ) || exit();

if( !class_exists( 'OVADEP_assets' ) ){
	class OVADEP_assets{

		public function __construct(){

			add_action( 'wp_enqueue_scripts', array( $this, 'ovadep_enqueue_scripts' ), 10, 0 );

			/* Add JS for Elementor */
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'ova_enqueue_scripts_elementor_dep' ) );
		}

		public function ovadep_enqueue_scripts(){

			// Init Css
			wp_enqueue_style( 'ovadep_style', OVADEP_PLUGIN_URI.'assets/css/frontend/ovadep-style.css' );		

		}

		// Add JS for elementor
		public function ova_enqueue_scripts_elementor_dep(){
			wp_enqueue_script( 'script-elementor-dep', OVADEP_PLUGIN_URI. 'assets/js/script-elementor.js', [ 'jquery' ], false, true );
		}

	}
	new OVADEP_assets();
}
