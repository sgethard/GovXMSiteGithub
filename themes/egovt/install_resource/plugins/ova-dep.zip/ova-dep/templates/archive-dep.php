<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();

$number_column = get_theme_mod( 'ova_dep_layout', 'three_column' );

?>

<div class="container">
	<div class="row">
		<div class="ova_dep_wrap archive_dep <?php echo esc_attr( $number_column ) ?>">
			<div class="content">
				<?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<div class="items elementor-items">
						<div class="wp-item">
						<?php 

						$id = get_the_id();

						$class_icon = get_post_meta( $id, 'ova_dep_met_class_icon', true );
						$title = get_the_title();
						$excerpt = get_the_excerpt();
						$thumbnail = get_the_post_thumbnail( $id, 'large', array('class'=> 'img-responsive' ));
						?>
						<div class="ova-media">
							<a href="<?php echo get_the_permalink(); ?>">
								<?php echo $thumbnail; ?>
							</a>
						</div>
						<div class="ova-content">
							<?php if( $class_icon ){ ?>
							<div class="icon">
								<span>
									<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
								</span>
							</div>
							<?php } ?>
							<h2 class="title">
								<a class="second_font" href="<?php echo get_the_permalink(); ?>">
									<?php echo $title; ?>
								</a>
							</h2>
							<?php if( ! empty( $excerpt ) ){ ?>
							<div class="descption">
								<?php printf($excerpt); ?>
							</div>
							<?php } ?>
							<a class="second_font readmore" href="<?php echo get_the_permalink(); ?>" >
								<?php echo esc_html__( 'Read More', 'ova-dep' ); ?>
								<i data-feather="arrow-right"></i>
							</a>
						</div>

						</div>

					</div>

				<?php endwhile; endif; wp_reset_postdata(); ?>
			</div>
			
			<?php 
				egovt_pagination_theme();
			?>

		</div>
	</div>
</div>

<?php 
 get_footer();