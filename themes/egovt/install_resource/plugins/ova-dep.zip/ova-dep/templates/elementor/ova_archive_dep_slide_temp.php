<?php if ( !defined( 'ABSPATH' ) ) exit();

$category = $args['category'];
$show_icon = $args['show_icon'];
$show_title = $args['show_title'];
$show_excerpt = $args['show_excerpt'];
$show_readmore = $args['show_readmore'];

$data_options['items']              = $args['item_number'];
$data_options['slideBy']            = $args['slides_to_scroll'];
$data_options['margin']             = $args['margin_items'];
$data_options['autoplayHoverPause'] = $args['pause_on_hover'] === 'yes' ? true : false;
$data_options['loop']               = $args['infinite'] === 'yes' ? true : false;
$data_options['autoplay']           = $args['autoplay'] === 'yes' ? true : false;
$data_options['autoplayTimeout']    = $args['autoplay_speed'];
$data_options['smartSpeed']         = $args['smartspeed'];
$data_options['dots']               = $args['dot_control'] === 'yes' ? true : false;

if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'ova_dep',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
	);
} else {
	$args_new= array(
		'post_type' => 'ova_dep',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_dep',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_dep_order = [];
if( $args['orderby_post'] === 'ova_dep_met_order_dep' ) {
	$args_dep_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_dep_order = [
		'orderby'        => $args['orderby_post'],
	];
}
$args_dep = array_merge( $args_new, $args_dep_order );

$deps  = new \WP_Query($args_dep);

?>

<div class="ova_archive_dep_slide archive_dep ">
	<div class="content ova_dep_slide owl-carousel owl-theme" data-options="<?php echo esc_attr(json_encode($data_options)) ?>">
		<?php if( $deps->have_posts() ) : while ( $deps->have_posts() ) : $deps->the_post(); ?>

			<div class="items elementor-items">
				<div class="wp-item">
				<?php 

				$id = get_the_id();

				$class_icon = get_post_meta( $id, 'ova_dep_met_class_icon', true );
				$title = get_the_title();
				$excerpt = get_the_excerpt();
				$thumbnail = get_the_post_thumbnail( $id, 'large', array('class'=> 'img-responsive' ));
				$thumbnail_url = get_the_post_thumbnail_url( $id, 'full' );

				// echo '$thumbnail_url: ' .$thumbnail_url . '<br>';
				?>

				<div class="ova-media">
					<a href="<?php echo get_the_permalink(); ?>" title="<?php echo $title; ?>" style="background-image: url(<?php echo esc_attr( $thumbnail_url ); ?>)">
						<?php echo $thumbnail; ?>
					</a>
				</div>
				<div class="ova-content">
					<?php if( $show_icon === 'yes' ){ ?>
						<div class="icon">
							<span>
								<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
							</span>
						</div>
					<?php } ?>
					<?php if( $show_title === 'yes' ){ ?>
					<h2 class="title">
						<a class="second_font" href="<?php echo get_the_permalink(); ?>">
							<?php echo $title; ?>
						</a>
					</h2>
					<?php } ?>
					<?php if( ! empty( $excerpt ) && $show_excerpt === 'yes' ){ ?>
						<div class="descption">
							<?php echo $excerpt; ?>
						</div>
					<?php } ?>
					<?php if( $show_readmore === 'yes' ){ ?>
					<a class="second_font readmore" href="<?php echo get_the_permalink(); ?>" >
						<?php echo esc_html__( 'Read More', 'ova-dep' ); ?>
						<i data-feather="arrow-right"></i>
					</a>
					<?php } ?>
				</div>

				</div>
			</div>

		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>

</div>

<?php 
