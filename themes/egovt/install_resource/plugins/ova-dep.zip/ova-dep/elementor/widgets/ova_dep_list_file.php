<?php
namespace ova_dep_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_dep_list_file extends Widget_Base {


	public function get_name() {
		return 'ova_dep_list_file';
	}

	public function get_title() {
		return __( 'File List In Department', 'ova-dep' );
	}

	public function get_icon() {
		return 'fa fa-file-text-o';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-dep' ),
			]
		);

		
		$this->add_control(
			'id_dep',
			[
				'label'   => __( 'Department Id', 'ova-dep' ),
				'type'    => Controls_Manager::TEXT,
			]
		);


	}


	protected function render() {

		$settings = $this->get_settings();

		$template = apply_filters( 'el_elementor_ova_dep', 'elementor/ova_dep_list_file.php' );

		ob_start();
		ovadep_get_template( $template, $settings );
		echo ob_get_clean();
		
	}
}
