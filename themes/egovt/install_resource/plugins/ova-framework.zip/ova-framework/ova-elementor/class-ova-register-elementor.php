<?php

namespace ova_framework;

use ova_framework\widgets\ova_menu;
use ova_framework\widgets\ova_logo;
use ova_framework\widgets\ova_header;
use ova_framework\widgets\ova_contact_info;
use ova_framework\widgets\ova_search_popup;
use ova_framework\widgets\ova_language;
use ova_framework\widgets\ova_social;
use ova_framework\widgets\ova_menu_page;
use ova_framework\widgets\ova_skill_bar;
use ova_framework\widgets\ova_heading;
use ova_framework\widgets\ova_education;
use ova_framework\widgets\ova_testimonial;
use ova_framework\widgets\ova_list_checked;
use ova_framework\widgets\ova_list_checked2;
use ova_framework\widgets\ova_feature;
use ova_framework\widgets\ova_feature2;
use ova_framework\widgets\ova_box_learnmore;
use ova_framework\widgets\ova_blog;
use ova_framework\widgets\ova_blog2;
use ova_framework\widgets\ova_blog3;
use ova_framework\widgets\ova_time_countdown;
use ova_framework\widgets\ova_history;
use ova_framework\widgets\ova_feature_box;
use ova_framework\widgets\ova_list_link;
use ova_framework\widgets\ova_box_resource;
use ova_framework\widgets\ova_box_contact;
use ova_framework\widgets\ova_contact_slide;
use ova_framework\widgets\ova_box_signature;
use ova_framework\widgets\ova_box_feature_2;
use ova_framework\widgets\ova_box_feature_3;
use ova_framework\widgets\ova_box_resource_2;
use ova_framework\widgets\ova_blog_slide;
use ova_framework\widgets\ova_feature_box_2;
use ova_framework\widgets\ova_feature_box_3;
use ova_framework\widgets\ova_shortcode_donation;
use ova_framework\widgets\ova_mission;
use ova_framework\widgets\ova_search_all;
use ova_framework\widgets\ova_icon_banner;
use ova_framework\widgets\ova_title;
use ova_framework\widgets\ova_tabs;
use ova_framework\widgets\ova_iso;
use ova_framework\widgets\ova_give_donations;
use ova_framework\widgets\ova_slide;







if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly




/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Ova_Register_Elementor {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {
		$this->add_actions();
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {

		// Register Header Footer Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'add_hf_category' ) );

	     // Register Ovatheme Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'add_ovatheme_category' ) );
	    
		
		add_action( 'elementor/widgets/register', [ $this, 'on_widgets_registered' ] );
		

	}

	
	public  function add_hf_category(  ) {
	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'hf',
	        [
	            'title' => __( 'Header Footer', 'ova-framework' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}

	
	public function add_ovatheme_category(  ) {

	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'ovatheme',
	        [
	            'title' => __( 'Ovatheme', 'ova-framework' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}


	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widget();
	}

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function includes() {
		
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-menu.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-logo.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-header.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_contact_info.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_search_popup.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_language.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_social.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_menu_page.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_skill_bar.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_heading.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_education.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_testimonial.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_checked.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_checked2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_learnmore.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog3.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_time_countdown.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_history.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature_box.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_list_link.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_resource.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_contact.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_contact_slide.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_signature.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_feature_2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_feature_3.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_box_resource_2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog_slide.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature_box_2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_feature_box_3.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_shortcode_donation.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_mission.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_search_all.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_icon_banner.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_title.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_tabs.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_iso.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_give_donations.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_slide.php';
		

		
	}

	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {

		\Elementor\Plugin::instance()->widgets_manager->register( new ova_menu() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_logo() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_header() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_contact_info() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_search_popup() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_language() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_social() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_menu_page() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_skill_bar() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_heading() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_education() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_testimonial() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_list_checked() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_list_checked2() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_feature() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_feature2() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_learnmore() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_blog() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_blog2() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_blog3() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_time_countdown() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_history() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_feature_box() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_list_link() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_resource() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_contact() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_contact_slide() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_signature() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_feature_2() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_feature_3() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_box_resource_2() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_blog_slide() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_feature_box_2() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_feature_box_3() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_shortcode_donation() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_mission() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_search_all() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_icon_banner() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_title() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_tabs() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_iso() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_give_donations() );
		\Elementor\Plugin::instance()->widgets_manager->register( new ova_slide() );
		
		
	}
	    
	

}

new Ova_Register_Elementor();





