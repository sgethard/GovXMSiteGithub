<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_signature extends Widget_Base {

	public function get_name() {
		return 'ova_box_signature';
	}

	public function get_title() {
		return __( 'Feature Signature', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('47th mayor of Amon City, From on May 25 2018.','ova-framework'),
			]
		);


		$this->add_control(
			'excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'We differentiate ourselves from all the other Australian VC by the fact that we come from startup and blockchain industry ourselves. We are tired of seeing that.','ova-framework' ),
			]
		);

		$this->add_control(
			'name',
			[
				'label' => __( 'Name', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('- Andrew Simmons,','ova-framework'),
			]
		);

		$this->add_control(
			'job',
			[
				'label' => __( 'Job', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('City Mayor,','ova-framework'),
			]
		);

		$this->add_control(
			'image_signature',
			[
				'label'   => 'Image Signature',
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$title = $settings['title'];
		$excerpt = $settings['excerpt'];
		$name = $settings['name'];
		$job = $settings['job'];
		$image_signature = $settings['image_signature'];
	
		?>
		<div class="ova_box_signature">
			<div class="box_signature">
				<?php if( $title ){ ?>
				<h3 class="title">
					<?php echo $title ?>
				</h3>
				<?php } ?>

				<?php if( $excerpt ){ ?>
				<p class="excerpt">
					<?php echo $excerpt ?>
				</p>
				<?php } ?>

				<?php if( $name || $job ){ ?>
					<div class="name-job">
						<span class="name second_font"><?php echo esc_html( $name ) ?></span>
						<span class="job"><?php echo esc_html( $job ) ?></span>
					</div>
				<?php } ?>
				<?php if( $image_signature ){ ?>
					<div class="image-signature">
						<img src="<?php echo esc_attr( $image_signature['url'] ) ?>" alt="">
					</div>
				<?php } ?>
			</div>
		</div>

		<?php
		// end if version
	}
}


