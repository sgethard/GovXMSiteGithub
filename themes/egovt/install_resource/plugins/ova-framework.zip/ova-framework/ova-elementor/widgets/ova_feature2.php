<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_feature2 extends Widget_Base {

	public function get_name() {
		return 'ova_feature2';
	}

	public function get_title() {
		return __( 'Feature2', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Visiting City','ova-framework'),
			]
		);
	

		$this->add_control(
			'excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'EGovt is the largest global 
                 crowdfunding community connecting 
                 nonprofits, donors, and companies','ova-framework' ),
			]
		);

		$this->add_control(
			'read_more',
			[
				'label' => __( 'Learn More', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Learn More','ova-framework'),
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => '#',
			]
		);

		$this->add_control(
			'target_link',
			[
				'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
				'type' 		=> Controls_Manager::SWITCHER,
				'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
				'label_off' => esc_html__( 'No', 'ova-framework' ),
				'default' 	=> 'no',
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color Title ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature2 .box .content_1 .title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_feature2 .box .content_1 .title a',
			]
		);
		$this->add_control(
			'background_1',
			[
				'label' => __( 'Background 1 ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature2 .box .content_1' => 'background : {{VALUE}};',
				],
			]
		);

	
		$this->add_control(
			'color_excerpt',
			[
				'label' => __( 'Color Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature2 .box .content_2 .excerpt' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',
				'selector' => '{{WRAPPER}} .ova_feature2 .box .content_2 .excerpt',
			]
		);


		$this->add_control(
			'color_read',
			[
				'label' => __( 'Color Button ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature2 .box .content_2 .readmore' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_feature2 .box .content_2 .readmore:after' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'read_typography',
				'selector' => '{{WRAPPER}} .ova_feature2 .box .content_2 .readmore',
			]
		);

		$this->add_control(
			'color_button_hover',
			[
				'label' => __( 'Color Button Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature2 .box .content_2 .readmore:hover' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_feature2 .box .content_2 .readmore:hover:after' => 'background : {{VALUE}};',
				],
			]
		);
			$this->add_control(
			'background_title',
			[
				'label' => __( 'Background 2 ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature2 .box .content_2' => 'background : {{VALUE}};',
				],
			]
		);



	

		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$title = $settings['title'];
		$excerpt = $settings['excerpt'];
		$read_more = $settings['read_more'];
		$link = $settings['link'];
		$target 	= '';
		if ( 'yes' == $settings['target_link'] ) {
			$target = ' target="_blank"';
		}

		?>

	
		<div class="ova_feature2 ">
			<div class="box">
		
			<div class="content_1">

				<?php if( ! empty( $title ) ){ ?>
					<h3 class="title">
						<a class="second_font" href="<?php echo esc_url( $link ) ?>"<?php echo esc_html( $target ); ?>>
							<?php echo $title ?>
						</a>
					</h3>
				<?php } ?>
			</div>

				<div class="content_2">
					<?php if( ! empty( $excerpt ) ){ ?>
					<p class="excerpt">
						<?php echo esc_html( $excerpt ) ?>
					</p>
					<?php } ?>
					
					<?php if( ! empty( $read_more ) ){ ?>
					<a href="<?php echo esc_url( $link ) ?>" class="second_font readmore"<?php echo esc_html( $target ); ?>>
						<?php echo esc_html( $read_more ) ?>
						<i data-feather="chevron-right"></i>
					</a>
					<?php } ?>
				</div>
			</div>
			</div>
			

	
	
		<?php
		}
		// end if version
	}



