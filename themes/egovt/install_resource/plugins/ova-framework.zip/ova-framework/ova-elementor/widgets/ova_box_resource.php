<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_resource extends Widget_Base {

	public function get_name() {
		return 'ova_box_resource';
	}

	public function get_title() {
		return __( 'Ova Box Resource', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'text_number',
			[
				'label' => __( 'Number', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('01','ova-framework'),
			]
		);
		

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Agriculture & Food','ova-framework'),
			]
		);

		$this->add_control(
			'text_read_more',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('See More','ova-framework'),
			]
		);

		$this->add_control(
			'link_read_more',
			[
				'label' 	=> esc_html__( 'Link Read More', 'ova-framework' ),
				'type' 		=> Controls_Manager::TEXT,
				'default' 	=> '#',
			]
		);

		$this->add_control(
			'target_link',
			[
				'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
				'type' 		=> Controls_Manager::SWITCHER,
				'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
				'label_off' => esc_html__( 'No', 'ova-framework' ),
				'default' 	=> 'no',
			]
		);

		$repeater = new \Elementor\Repeater();

				$repeater->add_control(
					'text_link',
					[
						'label'   => __( 'Text Link', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'link',
					[
						'label' 	=> esc_html__( 'Link', 'ova-framework' ),
						'type' 		=> Controls_Manager::TEXT,
						'default' 	=> '#',
					]
				);

				$repeater->add_control(
					'item_target_link',
					[
						'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
						'type' 		=> Controls_Manager::SWITCHER,
						'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
						'label_off' => esc_html__( 'No', 'ova-framework' ),
						'default' 	=> 'no',
					]
				);

				$this->add_control(
					'tab',
					[
						'label'       => 'Item',
						'type'        => Controls_Manager::REPEATER,
						'fields'      => $repeater->get_controls(),
						'default' => [
							[
								'text_link' => __('Farming Sector', 'ova-framework'),
								'link' => '#',
								'item_target_link' => 'no',
							],
							[
								'text_link' => __('Agri Industry Development', 'ova-framework'),
								'link' => '#',
								'item_target_link' => 'no',
							],
							[
								'text_link' => __('Forestry', 'ova-framework'),
								'link' => '#',
								'item_target_link' => 'no',
							],
							[
								'text_link' => __('Rural Environment', 'ova-framework'),
								'link' => '#',
								'item_target_link' => 'no',
							],
							[
								'text_link' => __('Food Safty', 'ova-framework'),
								'link' => '#',
								'item_target_link' => 'no',
							],
						],
						'title_field' => '{{{ text_link }}}',
					]
				);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_number',
			[
				'label' => __( 'Number', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'number_typography',
				'selector' => '{{WRAPPER}} .ova_box_resource .text_number span',
			]
		);

		$this->add_control(
			'color_number',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .text_number span' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'margin_number',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .text_number ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_box_resource .title a',
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_hover_title',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',
				'selector' => '{{WRAPPER}} .ova_box_resource ul.content li a',
			]
		);

		$this->add_control(
			'color_link',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource ul.content li a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_hover_link',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource ul.content li a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_link',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource ul.content li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_read_more',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'read_more_typography',
				'selector' => '{{WRAPPER}} .ova_box_resource .read_more a',
			]
		);

		$this->add_control(
			'color_read_more',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .read_more a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_hover_readmore',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .read_more a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bg_color_read_more',
			[
				'label' => __( 'Background Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .read_more a' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bg_color_hover_readmore',
			[
				'label' => __( 'Background Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .read_more a:hover' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_read_more',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_box_resource .read_more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$text_number = $settings['text_number'];
		$text_read_more = $settings['text_read_more'];
		$link_read_more = $settings['link_read_more'];
		$target_rm 		= '';
		if ( 'yes' == $settings['target_link'] ) {
			$target_rm = ' target="_blank"';
		}
		$title = $settings['title'];
		$tabs = $settings['tab'];
	
		?>
		<div class="ova_box_resource ">
			<?php if( $text_number ){ ?>
				<div class="text_number">
					<span class="second_font">
						<?php echo $text_number ?>
					</span>
				</div>
			<?php } ?>
			<?php if( $title ){ ?>
			<h3 class="title">
				<a href="<?php echo esc_url( $link_read_more ) ?>"<?php echo esc_attr( $target_rm ); ?>>
					<?php echo esc_html( $title ) ?>
				</a>
			</h3>
			<?php } ?>
			<?php if( $tabs ){ ?>
			<ul class="content">
				<?php foreach( $tabs as $tab ){ 
					$target 	= '';
					if ( 'yes' == $tab['item_target_link'] ) {
						$target = ' target="_blank"';
					}
				?>
					<li class="item">
						<a href="<?php echo esc_url( $tab['link'] ) ?>" class="second_font"<?php echo esc_attr( $target ); ?>>
							<?php echo esc_html( $tab['text_link'] ) ?>
						</a>
					</li>
				<?php } ?>
			</ul>
			<?php } ?>
			
			<?php if( $text_number ){ ?>
				<div class="read_more">
					<a href="<?php echo esc_url( $link_read_more ) ?>" class="second_font"<?php echo esc_attr( $target_rm ); ?>>
						<?php echo $text_read_more ?>
					</a>
				</div>
			<?php } ?>

		</div>
		<?php
	}
}


