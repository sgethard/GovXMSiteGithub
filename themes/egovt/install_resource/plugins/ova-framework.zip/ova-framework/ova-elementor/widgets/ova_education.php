<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_education extends Widget_Base {

	public function get_name() {
		return 'ova_education';
	}

	public function get_title() {
		return __( 'Ova Education', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
		

		$this->add_control(
			'time',
			[
				'label' => __( 'Time Duration', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('1979 – 1983','ova-framework'),
			]
		);

		

		$this->add_control(
			'position',
			[
				'label' => __( 'Position', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __('Master of Political Science','ova-framework'),
			]
		);

		$this->add_control(
			'college',
			[
				'label' => __( 'College', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __('Columbia University, CL','ova-framework'),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .ova-education' => 'text-align: {{VALUE}}',
				]
			]
		);

		$this->end_controls_section();
		

		$this->start_controls_section(
			'section_time',
			[
				'label' => __( 'Time', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'time_typography',
				'selector' => '{{WRAPPER}} .ova-education .time',
			]
		);

		$this->add_control(
			'color_time',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-education .time' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_time',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-education .time' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_position',
			[
				'label' => __( 'Position', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'position_typography',
				'selector' => '{{WRAPPER}} .ova-education .position',
			]
		);

		$this->add_control(
			'color_position',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-education .position' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'margin_position',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-education .position' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_college',
			[
				'label' => __( 'College', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'college_typography',
				'selector' => '{{WRAPPER}} .ova-education .college',
			]
		);

		$this->add_control(
			'color_college',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-education .college' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'margin_college',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-education .college' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$time = $settings['time'];
		$position = $settings['position'];
		$college = $settings['college'];
	
		?>
		<div class="ova-education">
			<div class="dot-education">
				<span></span>
			</div>
			<div class="content-education">
				<?php if (!empty($time)) { ?>
					<h3 class="time">
						<?php echo esc_html( $time ) ?>
					</h3>
				<?php } ?>

				<?php if (!empty($position)) { ?>
					<p class="position second_font">
						<?php echo esc_html( $position ) ?>
					</p>
				<?php } ?>
				<?php if (!empty($college)) { ?>
					<p class="college">
						<?php echo esc_html( $college ) ?>
					</p>
				<?php } ?>
			</div>

		</div>
		<?php
	}
}


