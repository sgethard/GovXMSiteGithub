<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_feature_2 extends Widget_Base {

	public function get_name() {
		return 'ova_box_feature_2';
	}

	public function get_title() {
		return __( 'Box Feature 2', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'flaticon-briefcase',
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => ' Image',
				'type'    => \Elementor\Controls_Manager::MEDIA,
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Business','ova-framework'),
			]
		);


		$this->add_control(
			'excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'This present moment is perfect simply due to the fact you’re experiencing it. you can get away.','ova-framework' ),
			]
		);

		$this->add_control(
			'text_readmore',
			[
				'label' => __( 'Text Read More', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('More Details','ova-framework'),
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => '#',
			]
		);

		$this->add_control(
			'target_link',
			[
				'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
				'type' 		=> Controls_Manager::SWITCHER,
				'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
				'label_off' => esc_html__( 'No', 'ova-framework' ),
				'default' 	=> 'no',
			]
		);


		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_2' => 'text-align: {{VALUE}}',
				]
			]
		);

		$this->add_responsive_control(
			'padding_box',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Icon Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_2 .icon i' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_box_feature_2 .icon i:before' => 'color : {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label' => __( 'Icon hover color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_2:hover .icon i' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_box_feature_2:hover .icon i:before' => 'color : {{VALUE}};',
				],
				
			]
		);

		

		$this->add_control(
			'bg_box_color',
			[
				'label' => __( 'Background Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_box_feature_2:hover' => 'background-color : {{VALUE}};',
					
				],
				
			]
		);


		$this->end_controls_section();


		// Style - Title
		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova_box_feature_2 .title',
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .title' => 'color : {{VALUE}};',
					],
					
				]
			);

			$this->add_control(
				'title_color_hover',
				[
					'label' => __( 'Title Color hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2:hover .title' => 'color : {{VALUE}};',
					],
					
				]
			);
			

		$this->end_controls_section(); // End Style - Title



		// Style - Description
		$this->start_controls_section(
			'desc_style',
			[
				'label' => __( 'Description Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography',
					'selector' => '{{WRAPPER}} .ova_box_feature_2 .excerpt',
				]
			);

			$this->add_responsive_control(
				'margin_desc',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'desc_color',
				[
					'label' => __( 'Description Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .excerpt' => 'color : {{VALUE}};',
					],
					
				]
			);

			$this->add_control(
				'desc_color_hover',
				[
					'label' => __( 'Description Color hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2:hover .excerpt' => 'color : {{VALUE}};',
					],
					
				]
			);
			

		$this->end_controls_section(); // End Style - Description


		// Style - Read More
		$this->start_controls_section(
			'readmore_style',
			[
				'label' => __( 'Read More Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'readmore_typography',
					'selector' => '{{WRAPPER}} .ova_box_feature_2 .readmore a',
				]
			);

			$this->add_responsive_control(
				'margin_readmore',
				[
					'label' => __( 'Read More Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .readmore a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'readmore_color',
				[
					'label' => __( 'Read More Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .readmore a' => 'color : {{VALUE}};',
					],
					
				]
			);

			$this->add_control(
				'readmore_color_hover',
				[
					'label' => __( 'Read More Color hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2:hover .readmore a' => 'color : {{VALUE}};',
					],
					
				]
			);

			$this->add_control(
				'button_text_color_hover',
				[
					'label' => __( 'Button Text color when hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_2 .readmore a:hover' => 'color : {{VALUE}};',
					],
					
				]
			);
			

		$this->end_controls_section(); // End Style - Description
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$class_icon = $settings['class_icon'];
		$title = $settings['title'];
		$excerpt = $settings['excerpt'];
		$text_readmore = $settings['text_readmore'];
		$link = $settings['link'];
		$target 	= '';
		if ( 'yes' == $settings['target_link'] ) {
			$target = ' target="_blank"';
		}
		$class_icon = $settings['class_icon'];
		$image = $settings['image']['url'];
	
	
		?>
		<div class="ova_box_feature_2">
				<?php if( $class_icon ){ ?>
				<div class="icon">
					<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
				</div>
				<?php } ?>

				<?php if( $image){ ?>
					<img src="<?php echo esc_attr($image); ?>" alt="">
				<?php } ?>

				<?php if( $title ){ ?>
				<h3 class="title">
					<?php echo $title; ?>
				</h3>
				<?php } ?>

				<?php if( $excerpt ){ ?>
				<p class="excerpt">
					<?php echo $excerpt; ?>
				</p>
				<?php } ?>

				<?php if( $excerpt ){ ?>
					<div class="readmore">
						<a class="second_font" href="<?php echo esc_attr( $link ); ?>"<?php echo esc_html( $target ); ?>><?php echo esc_html( $text_readmore ); ?></a>
					</div>
				<?php } ?>

		</div>

		<?php
		// end if version
	}
}


