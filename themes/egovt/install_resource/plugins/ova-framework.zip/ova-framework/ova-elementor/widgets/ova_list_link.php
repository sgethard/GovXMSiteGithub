<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_list_link extends Widget_Base {

	public function get_name() {
		return 'ova_list_link';
	}

	public function get_title() {
		return __( 'Ova Link List', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-link';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
		

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Online Goverment Service','ova-framework'),
			]
		);

		$this->add_control(
			'show_box_shadow',
			[
				'label' => __( 'Show Box Shadow', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ova-framework' ),
				'label_off' => __( 'Hide', 'ova-framework' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'chevron-right', 'ova-framework' ),
				
			]
		);


		$this->add_control(
			'class_icon_hover',
			[
				'label' => __( 'Class Icon Hover', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'arrow-right', 'ova-framework' ),
				
			]
		);
		

		$repeater = new \Elementor\Repeater();

				$repeater->add_control(
					'text_link',
					[
						'label'   => __( 'Link Text', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'link',
					[
						'label'   => __( 'Link', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
						'default' => '#',
					]
				);

				$repeater->add_control(
					'target_link',
					[
						'label' 	=> esc_html__( 'Target Link', 'ova-framework' ),
						'type' 		=> Controls_Manager::SWITCHER,
						'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
						'label_off' => esc_html__( 'No', 'ova-framework' ),
						'default' 	=> 'no',
					]
				);

				$this->add_control(
					'tab',
					[
						'label'       => 'Item',
						'type'        => Controls_Manager::REPEATER,
						'fields'      => $repeater->get_controls(),
						'default' => [
							[
								'text_link' 	=> __('Public Service Identity', 'ova-framework'),
								'link' 			=> '#',
								'target_link' 	=> 'no',
							],
							[
								'text_link' 	=> __('Apply for a City Job', 'ova-framework'),
								'link' 			=> '#',
								'target_link' 	=> 'no',
							],
							[
								'text_link' 	=> __('Professional Licenses', 'ova-framework'),
								'link' 			=> '#',
								'target_link' 	=> 'no',
							],
							[
								'text_link' 	=> __('Apply for Business License', 'ova-framework'),
								'link' 			=> '#',
								'target_link' 	=> 'no',
							],
							[
								'text_link' 	=> __('Online Court Services', 'ova-framework'),
								'link' 			=> '#',
								'target_link' 	=> 'no',
							],
						],
						'title_field' => '{{{ text_link }}}',
					]
				);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_Box',
			[
				'label' => __( 'Box', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'max_width_box',
			[
				'label' => __( 'Max Width', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'max' => 2000,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_list_link' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'bg_color_box',
			[
				'label' => __( 'Background Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_link' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding_box',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_list_link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_list_link .title',
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_link .title' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_list_link .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_text_link',
			[
				'label' => __( 'Text Link', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_link_typography',
				'selector' => '{{WRAPPER}} .ova_list_link ul.content li a',
			]
		);

		$this->add_control(
			'color_text_link',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_link ul.content li a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_text_link_hover',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_link ul.content li a:hover' => 'color : {{VALUE}};',
				],
			]
		);

			$this->add_control(
			'color_back_text_link_hover',
			[
				'label' => __( 'Background Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_list_link ul.content li:hover' => 'background-color : {{VALUE}};',
					'{{WRAPPER}} .ova_list_link ul.content li:hover:before' => 'background-color : {{VALUE}};',
					'{{WRAPPER}} .ova_list_link ul.content li:hover:after' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding_text_link',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_list_link ul.content li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_text_link',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_list_link ul.content li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'font_size_icon',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px'],
					'range' => [
						'px' => [
							'max' => 100,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_list_link ul.content li a svg' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_icon',
				[
					'label' => __( 'Color ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_list_link ul.content li a svg' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_icon_hover',
				[
					'label' => __( 'Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_list_link ul.content li:hover a svg' => 'color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_border',
			[
				'label' => __( 'Border', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'color_border',
				[
					'label' => __( 'Color ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_list_link ul.content li:not(:last-child) a' => 'border-bottom-color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$show_box_shadow = $settings['show_box_shadow'];
		$class_shadow = ( $show_box_shadow == 'yes' ) ? 'box-shadow' : '';

		$title = $settings['title'];
		$tabs = $settings['tab'];

		$icon = $settings['class_icon'];
		$icon2 = $settings['class_icon_hover'];
	
		?>
		<div class="ova_list_link <?php echo esc_attr( $class_shadow ) ?>">
			<?php if( $title ){ ?>
			<h3 class="title">
				<?php echo esc_html( $title ) ?>
			</h3>
			<?php } ?>
			<?php if( $tabs ){ ?>
			<ul class="content">
				<?php foreach( $tabs as $tab ){
					$target = ( 'yes' == $tab['target_link'] ) ? ' target="_blank"' : '';
				?>
					<li class="item">
						<a href="<?php echo esc_url( $tab['link'] ) ?>"<?php echo esc_attr( $target ); ?>>
							<?php echo esc_html( $tab['text_link'] ) ?>
							<?php if( ! empty( $icon ) ){ ?>
							<span class="icon">
								<i data-feather="<?php echo esc_html( $icon ) ?>"></i>
							</span>
						    <?php } ?>
						    <?php if( ! empty( $icon2 ) ){ ?>
							<span class="icon-hover">
								<i data-feather="<?php echo esc_html( $icon2 ) ?>"></i>
							</span>
							 <?php } ?>
						</a>

					</li>
				<?php } ?>
			</ul>
			<?php } ?>
		</div>
		<?php
	}
}


