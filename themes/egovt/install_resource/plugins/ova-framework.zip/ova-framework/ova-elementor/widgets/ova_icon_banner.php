<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_icon_banner extends Widget_Base {

	public function get_name() {
		return 'ova_icon_banner';
	}

	public function get_title() {
		return __( 'Icon Banner Service', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);



		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'flaticon-calendar', 'ova-framework' ),
				
			]
		);
	
	   $this->add_control(
			'text',
			[
				'label' => __( 'Text', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __('NEWS & EVENTS ','ova-framework'),
			]
		);
		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
				'default' => [
					'url' => '#',
				],
			]
		);



	

		$this->end_controls_section();

			$this->start_controls_section(
			'section_icon_text',
			[
				'label' => __( 'Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			
		
				$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color Icon ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-icon i:before' => 'color : {{VALUE}};',
				],
			]
		);
						$this->add_control(
			'color_icon_hover',
			[
				'label' => __( 'Color Icon Hover ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner-icon:hover .bn2-icon i:before' => 'color : {{VALUE}} !important;',
				],
			]
		);
				$this->add_control(
			'font_size_icon',
			[
				'label' => __( 'Font Size', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-icon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}  .bn2-icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment Icon', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-icon' => 'justify-content: {{VALUE}}',
				]
			]
		);

					$this->add_responsive_control(
			'margin_icon',
			[
				'label' => __( 'Margin Icon', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

				$this->add_control(
			'color_text',
			[
				'label' => __( 'Color Text ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-text span' => 'color : {{VALUE}};',
				],
			]
		);
						$this->add_control(
			'color_text_hover',
			[
				'label' => __( 'Color Text Hover ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner-icon:hover .bn2-text span' => 'color : {{VALUE}} !important;',
				],
			]
		);

						$this->add_responsive_control(
			'align_text',
			[
				'label' => __( 'Alignment Text', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-text' => 'justify-content: {{VALUE}}',
				]
			]
		);
								$this->add_control(
			'color_icon2',
			[
				'label' => __( 'Color Icon 2 ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner-icon .bn2-text .bn2-icon2 i:before' => 'color : {{VALUE}};',
				],
			]
		);
						$this->add_control(
			'color_icon_hover2',
			[
				'label' => __( 'Color Icon 2 Hover ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .banner-icon:hover .bn2-text .bn2-icon2 i:before' => 'color : {{VALUE}} !important;',
				],
			]
		);


	
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$icon = $settings['class_icon'];
		$title = $settings['text'];
		$target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';

	
		?>
		<a   href="<?php echo $settings['link']['url'] ?>" <?php echo $target . ' ' . $nofollow ?>>
        <div class="banner-icon">
		
		<div class="bn2-icon">
			   <i class = "<?php echo esc_html( $icon ) ?>"></i>
	   </div>
	   <div class="bn2-text"><span class="second_font"><?php echo esc_html__($title) ?></span>
	   <div class="bn2-icon2"><i class = "flaticon-next"></i></div>
	   </div>

	   </div>
	   </a>



		<?php

	}
}


