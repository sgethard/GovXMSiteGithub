<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

require_once( OVAEV_PLUGIN_PATH. '/admin/widget/class-ovaev-category-widget.php' );
require_once( OVAEV_PLUGIN_PATH. '/admin/widget/class-ovaev-tag-widget.php' );
require_once( OVAEV_PLUGIN_PATH. '/admin/widget/class-ovaev-list-event-widget.php' );
require_once( OVAEV_PLUGIN_PATH. '/admin/widget/class-ovaev-event-feature-widget.php' );