<?php if ( !defined( 'ABSPATH' ) ) exit(); 

if( isset( $args['id'] ) ){
	$id = $args['id'];
}else{
	$id = get_the_id();	
}


$url_img = get_the_post_thumbnail_url( $id, 'post-thumbnail' );

?>

<a href="<?php echo the_permalink();?>" class="event-thumbnail" style="background-image:url(<?php echo esc_url( $url_img ) ?>);" title="<?php echo get_the_title($id); ?>">						
	<?php echo get_the_post_thumbnail( $id, 'post-thumbnail' ); ?>
</a>
