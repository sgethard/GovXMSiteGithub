<?php if ( !defined( 'ABSPATH' ) ) exit();
get_header( );

$id = get_the_ID();

$list_document 			= get_post_meta( $id, 'ova_sev_met_list_file_sev', true );
$file_sev_sidebar 		= get_post_meta( $id, 'ova_sev_met_file_sev_sidebar', true );
$file_sev_sidebar_id 	= get_post_meta( $id, 'ova_sev_met_file_sev_sidebar_id', true );

$link_image = get_post_meta( $id, 'ova_sev_met_link_image', true );
$image = get_post_meta( $id, 'ova_sev_met_image', true );


$link_archive_service = get_post_type_archive_link('ova_sev');
$link_all_service = get_theme_mod( 'ova_sev_link_all_service' ) ? get_theme_mod( 'ova_sev_link_all_service' ) : $link_archive_service;

$orderby 	= apply_filters( 'ova_sev_ft_orderby_single', 'ova_sev_met_order_sev' );
$order 		= apply_filters( 'ova_sev_ft_order_single', 'ASC' );

if ( 'ova_sev_met_order_sev' === $orderby ) {
	$args = array(
		'post_type' => 'ova_sev',
		'posts_per_page' => -1,
		'orderby' 	=> 'meta_value_num',
		'order' 	=> $order,
		'meta_type' => 'NUMERIC',
		'meta_key' 	=> 'ova_sev_met_order_sev'
	);
} else {
	$args = array(
		'post_type' => 'ova_sev',
		'posts_per_page' => -1,
		'orderby' 	=> $orderby,
		'order' 	=> $order,
	);
}

$list_sevs = get_posts( $args );

?>

<div class="container">
	<div class="row">
		<div class="ova_sev_wrap ova_sev_single">
			
			<div class="ova_sev_content">

				<?php if( have_posts() ) : while( have_posts() ) : the_post();
					the_content();
		 		?>
		 		<?php endwhile; endif; wp_reset_postdata(); ?>


				<?php if( has_filter( 'ova_share_social' ) ){ ?>
			        <div class="share_social">
			        	<span class="ova_label second_font"><?php esc_html_e('Share Article ', 'ova-sev'); ?></span>
			        	<?php echo apply_filters('ova_share_social', get_the_permalink(), get_the_title() ); ?>
			        </div>
		        <?php } ?>

		        <?php
			        if( comments_open( get_the_ID() ) ) {
			        	comments_template(); 
			        }
		        ?>
			</div>
			<!-- end ova_sev_content -->
			<div class="ova-sev-sidebar">
				<div class="ova_info">

					<div class="ova-list-sev">
						<h3 class="title-list-sev second_font">
							<a href="<?php echo esc_attr( $link_all_service ); ?>">
								<i data-feather="chevron-left"></i>
								<?php echo esc_html__( 'All Services', 'ova-sev' ); ?>
							</a>
						</h3>
						<ul>
						<?php
							if ($list_sevs) {
								foreach ( $list_sevs as $sev ) {
									$id_sev = $sev->ID;
									$title_sev = $sev->post_title;
									$class_active = ( $id == $id_sev ) ? 'active' : '';

									?>
									<li class="<?php echo esc_attr( $class_active ); ?>">
										<a class="second_font" href="<?php echo get_the_permalink( $id_sev ); ?>">
											<?php  echo esc_html( $title_sev ) ;?>
										</a>
									</li>
									<?php
								}
							}
						?>
						</ul>
					</div>
					<!-- end ova-list-cat -->

					<?php if( ! empty( $file_sev_sidebar ) ){  
							$name_file = basename( $file_sev_sidebar );
							$ext_file = pathinfo( $name_file, PATHINFO_EXTENSION );

							if ( $file_sev_sidebar_id ) {
								// Get post from $file_id
								$files = ova_dep_get_name_files( $file_sev_sidebar_id );
								if ( !empty( $files ) ) {
									foreach ($files as $file) {
										$name_file = $file->post_title ? $file->post_title : $file->post_excerpt;
									}
								}
							}

							// Check empty $name_file
							if ( empty( $name_file ) ) {
								$name_file = basename( $file_sev_sidebar );
							}
						?>
							<div class="sev-file-sidebar">
								<span class="icon-attachment">
									<?php echo ova_doc_get_icon_attachment_file( $ext_file ); ?>
								</span>

								<span class="ova-file-name-size">
									<span class="ova-file-name">
										<a href="<?php echo $file_sev_sidebar ?>" download>
											<?php echo esc_html( $name_file ); ?>
										</a>
									</span>
									<span class="ova-file-size">
										<span class="type">
											<?php echo esc_html( $ext_file ); ?>
										</span>
										<span class="file-size">
											(<?php echo ova_doc_get_file_size( $file_sev_sidebar ) . esc_html__( 'kb', 'ova-doc' ); ?>)
										</span>
									</span>
								</span>
							</div>
					<?php } ?>

					<?php if( ! empty( $image ) ){ ?>
					<div class="ova-media">
						<a href="<?php echo esc_url( $link_image ) ?>">
							<img src="<?php echo esc_url( $image ); ?>" class="img-responsive" alt="<?php echo get_the_title(); ?>">
						</a>
					</div>
					<?php } ?>
				</div>
			</div>
			<!-- end ova-sev-sidebar -->
		</div>
		<!-- end ova_sev_single -->
	</div>
	<!-- end row -->
</div>
<!-- end container -->

<?php get_footer( );
