<?php if ( !defined( 'ABSPATH' ) ) exit();

$category = $args['category'];
$number_column = $args['number_column'];
$post_per_page = $args['total_count'];



if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'ova_sev',
		'post_status' => 'publish',
		'posts_per_page' => $post_per_page,
	);
} else {
	$args_new= array(
		'post_type' => 'ova_sev',
		'post_status' => 'publish',
		'posts_per_page' => $post_per_page,
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_sev',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}
$args_sev_order = [];
if( $args['orderby_post'] === 'ova_sev_met_order_sev' ) {
	$args_sev_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => $args['order_post'],
	];
} else { 
	$args_sev_order = [
		'orderby' => $args['orderby_post'],
		'order'   => $args['order_post'],
	];
}

$args_sev = array_merge( $args_new, $args_sev_order );

$sevs  = new \WP_Query($args_sev);

?>


<div class="ova_archive_sev archive_sev <?php echo esc_attr( $number_column ); ?>">
	<div class="content">
		<div class="wp-content">
		<?php if( $sevs->have_posts() ) : while ( $sevs->have_posts() ) : $sevs->the_post(); ?>

			<div class="items elementor-items">
				<div class="wp-items">
				<?php 
				$id = get_the_id();

				$class_icon = get_post_meta( $id, 'ova_sev_met_class_icon', true );
				$class_icon_hover = get_post_meta( $id, 'ova_sev_met_class_icon_hover', true );
				$title = get_the_title();
				$excerpt = get_the_excerpt();
				$link = get_the_permalink();
				?>

				<?php if( ! empty( $class_icon ) ) { ?>
					<div class="icon">
						<span class="<?php echo esc_attr( $class_icon ); ?>"></span>
					</div>
					<?php } ?>

					<?php if( ! empty( $title ) ){ ?>
						<h3 class="title">
							<a class="second_font" href="<?php echo esc_url( $link ); ?>">
								<?php echo $title; ?>
							</a>
						</h3>
					<?php } ?>

					<div class="content-sub">
						<?php if( ! empty( $excerpt ) ){ ?>
						<p class="excerpt">
							<?php echo esc_html( $excerpt ); ?>
						</p>
						<?php } ?>
						
						
						<a href="<?php echo esc_url( $link ); ?>" class="second_font readmore">
							<?php echo esc_html__( 'Read More', 'ova-sev' ); ?>
							<i data-feather="arrow-right"></i>
						</a>
						
					</div>
					<?php if( ! empty( $class_icon_hover ) ) { ?>
					<div class="icon-hide">
						<span class="<?php echo esc_attr( $class_icon_hover ); ?>"></span>
					</div>
					<?php } ?>
				</div>

			</div>

		<?php endwhile; endif; wp_reset_postdata(); ?>
		</div>
	</div>



</div>


<?php 
