<?php
$category = $args['category'];

$text_readmore = $args['text_readmore'];

$show_title = $args['show_title'];
$show_date = $args['show_date'];
$show_readmore = $args['show_readmore'];

if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'ova_doc',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count']
	);
} else {
	$args_new= array(
		'post_type' => 'ova_doc',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_doc',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}
$args_doc_order = [];
if( $args['orderby_post'] === 'ova_doc_met_order_doc' ) {
	$args_doc_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_doc_order = [
		'orderby'        => $args['orderby_post'],
	];
}

$args_doc = array_merge( $args_new, $args_doc_order );

$list_docs  = new \WP_Query($args_doc);

?>
<div class="ova-document-list">
	<div class="icon-doc">
		<i class="flaticon-google-docs"></i>
	</div>
	<div class="list-doc">
		<?php 
		if( $list_docs->have_posts() ){ 
			while( $list_docs->have_posts() ){
				$list_docs->the_post();
				$id = get_the_ID();
				$title = get_the_title( $id );
				$date_str = get_post_time();
				$date_format = get_option( 'date_format' );
				$date = date_i18n( $date_format, $date_str );

			?>
			<div class="item">
				<?php if( $show_title == 'yes' ){ ?>
				<h3 class="title">
					<a href="<?php echo get_the_permalink() ?>">
						<?php echo $title ?>
					</a>
				</h3>
				<?php } ?>
				<?php if( $show_date == 'yes' ){ ?>
				<p class="date">
					<?php echo esc_html( $date ) ?>
				</p>
				<?php } ?>

			</div>

		<?php } } wp_reset_postdata(); ?>

		<?php if( $show_readmore == 'yes' ){ ?>
			<div class="readmore">
				<a href="<?php echo get_post_type_archive_link('ova_doc') ?>" class="second_font">
				<?php echo esc_html( $text_readmore ) ?>
				<i data-feather="chevron-right"></i>
			</a>
			</div>
		
		<?php } ?>

	</div>
</div>