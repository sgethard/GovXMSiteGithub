<?php if ( !defined( 'ABSPATH' ) ) exit();
get_header( );
global $post;

$id = get_the_ID();

$list_document = get_post_meta( $id, 'ova_doc_met_list_document', true );

$image = get_theme_mod( 'doc_image_sidebar', '' );
$link_image = get_theme_mod( 'doc_link_image', '#' );
$number_column = get_theme_mod( 'ova_doc_layout', 'four_column' );

$args = array(
   'taxonomy' => 'cat_doc',
   'orderby' => 'name',
   'order'   => 'ASC'
);

$categories = get_categories($args);
$term_id = get_queried_object_id();

$class_active_all = $term_id == 0 ? 'active' : '';


?>
		<div class="ova_doc_wrap archive-doc <?php echo esc_attr( $number_column ) ?>">
			<div class="ova-doc-sidebar">
				<div class="ova_info">

					<div class="ova-list-cat">
						<p class="title-list-cat second_font"><?php echo esc_html__( 'Document Filter', 'ova-doc' ) ?></p>
						<ul>
							<li  class="<?php echo esc_attr( $class_active_all ) ?>"><a href="<?php echo esc_url( get_post_type_archive_link( 'ova_doc' ) ) ?>"><?php echo esc_html__( 'All Document', 'ova-doc' ) ?></a></li>
						<?php
							if ($categories) {
								foreach ( $categories as $cate ) {
									$class_active = ( $term_id == $cate->term_id ) ? 'active' : '';
									?>
									<li class="<?php echo esc_attr( $class_active ) ?>">
										<a href="<?php echo esc_url( get_term_link( $cate->term_id ) ) ?>">
											<?php echo esc_html( $cate->cat_name ) ?>
										</a>
									</li>
									<?php									
								}
							}
						?>
						</ul>
					</div>
					<!-- end ova-list-cat -->

					<?php if( ! empty( $image ) ){ ?>
					<div class="ova-media">
						<a href="<?php echo esc_url( $link_image ) ?>">
							<img src="<?php echo esc_url( $image ) ?>" class="img-responsive" alt="<?php echo get_the_title() ?>">
						</a>
					</div>
					<?php } ?>
				</div>
			</div>
			<div class="ova_doc_content">
				<div class="doc-list-item">
				<?php if( have_posts() ) : while ( have_posts() ) : the_post(); 
						$id = get_the_id();
					?>
					<div class="items-doc">
						<div class="item">
							<div class="doc-icon-title">
								<div class="icon-doc">
									<i class="flaticon-files-1"></i>
								</div>
								<div class="doc-title-item">
									<h2 class="doc-title">
										<a href="<?php echo get_the_permalink() ?>">
											<?php echo get_the_title() ?>
										</a>
									</h2>
									<div class="doc-meta">
										<span class=" doc-meta-general">
											<?php the_time( get_option( 'date_format' ));?>
										</span>
										<span class=" doc-categories">
											<?php get_category_doc_by_id_doc( $id ) ?>			       
									    </span>
									</div>
								</div>
							</div>

							<div class="doc-readmore">
								<a class="second_font" href="<?php echo get_the_permalink() ?>">
									<?php echo esc_html__( 'View Document', 'ova-doc' ) ?>
								</a>
							</div>
						</div>
					</div>
				<?php endwhile; endif; wp_reset_postdata(); ?>
				
				</div>
				<?php 
					egovt_pagination_theme();
				?>
			</div>
			
			<!-- end ova_doc_content -->
		</div>
		<!-- end ova_doc_single -->


<?php get_footer( );
